import React, { useEffect, useRef, useState } from 'react';
import { Tabs } from 'expo-router';
import { Animated, Easing, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Home, Dumbbell, BarChart3, Utensils, MapPin, Bot } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '@/theme';
import { useMotionPreferences } from '@/hooks/useMotionPreferences';

const icons = { index: Home, workout: Dumbbell, tracking: BarChart3, nutrition: Utensils, maps: MapPin, 'ai-coach': Bot };

function GoldTabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();
  const { fontScale } = useWindowDimensions();
  const { reduceMotion, isActive } = useMotionPreferences();
  const [width, setWidth] = useState(0);
  const slide = useRef(new Animated.Value(0)).current;
  const itemWidth = width / Math.max(state.routes.length, 1);
  useEffect(() => {
    const target = state.index * itemWidth;
    slide.stopAnimation();
    if (reduceMotion || !isActive) { slide.setValue(target); return; }
    const animation = Animated.timing(slide, {
      toValue: target, duration: 320, easing: Easing.out(Easing.cubic), useNativeDriver: true,
    });
    animation.start();
    return () => animation.stop();
  }, [isActive, itemWidth, reduceMotion, slide, state.index]);

  return (
    <View style={[styles.bar, { paddingBottom: Math.max(insets.bottom, 8), paddingLeft: insets.left + 8, paddingRight: insets.right + 8 }]}>
      <LinearGradient pointerEvents="none" colors={['transparent', 'rgba(231,190,115,0.40)', 'transparent']}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.edge} />
      <View onLayout={(event) => setWidth(event.nativeEvent.layout.width)} style={styles.row}>
        {width > 0 && <Animated.View pointerEvents="none" style={[styles.indicator, { width: itemWidth - 6, transform: [{ translateX: slide }] }]}>
          <LinearGradient colors={['rgba(231,190,115,0.17)', 'rgba(231,190,115,0.025)']} style={styles.fill} />
          <View style={styles.indicatorLine} />
        </Animated.View>}
        {state.routes.map((route, index) => {
          const focused = state.index === index;
          const options = descriptors[route.key].options;
          const label = typeof options.tabBarLabel === 'string' ? options.tabBarLabel : options.title ?? route.name;
          const Icon = icons[route.name as keyof typeof icons] ?? Home;
          return (
            <Pressable key={route.key} accessibilityRole="tab" accessibilityState={{ selected: focused }}
              accessibilityLabel={options.tabBarAccessibilityLabel ?? `${label} tab`}
              onPress={() => {
                const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
                if (!focused && !event.defaultPrevented) navigation.navigate(route.name, route.params);
              }}
              onLongPress={() => navigation.emit({ type: 'tabLongPress', target: route.key })}
              style={({ pressed }) => [styles.item, { minHeight: fontScale > 1.3 ? 76 : 64, opacity: pressed ? 0.65 : 1 }]}>
              <Icon size={22} strokeWidth={focused ? 2.1 : 1.6} color={focused ? colors.primary : colors.textTertiary} />
              <Text style={[styles.label, { color: focused ? colors.primary : colors.textTertiary }]}>{label}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

export default function TabLayout() {
  return (
    <Tabs tabBar={(props) => <GoldTabBar {...props} />} screenOptions={{ headerShown: false, lazy: true }}>
      <Tabs.Screen name="index" options={{ title: 'Home' }} />
      <Tabs.Screen name="workout" options={{ title: 'Workout' }} />
      <Tabs.Screen name="tracking" options={{ title: 'Tracking' }} />
      <Tabs.Screen name="nutrition" options={{ title: 'Nutrition' }} />
      <Tabs.Screen name="maps" options={{ title: 'Maps' }} />
      <Tabs.Screen name="ai-coach" options={{ title: 'AI Coach' }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  bar: { backgroundColor: '#13110E', borderTopWidth: 1, borderTopColor: colors.borderLight, paddingTop: 7 },
  edge: { position: 'absolute', top: 0, left: 24, right: 24, height: 1 },
  row: { flexDirection: 'row', position: 'relative' },
  item: { flex: 1, paddingVertical: 9, paddingHorizontal: 1, alignItems: 'center', justifyContent: 'center', gap: 5 },
  label: { fontSize: 10, lineHeight: 14, fontWeight: '600', textAlign: 'center' },
  indicator: { position: 'absolute', top: 0, bottom: 0, left: 3, borderRadius: 17, overflow: 'hidden' },
  fill: { ...StyleSheet.absoluteFillObject },
  indicatorLine: { position: 'absolute', height: 2, width: 18, borderRadius: 2, top: 0, alignSelf: 'center', backgroundColor: colors.primary },
});
